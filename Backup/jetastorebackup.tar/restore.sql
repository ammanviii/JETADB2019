--
-- NOTE:
--
-- File paths need to be edited. Search for $$PATH$$ and
-- replace it with the path to the directory containing
-- the extracted data files.
--
--
-- PostgreSQL database dump
--

-- Dumped from database version 9.6.10
-- Dumped by pg_dump version 10.5

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET client_min_messages = warning;
SET row_security = off;

ALTER TABLE ONLY public.supporttickets DROP CONSTRAINT supporttickets_orderid_fkey;
ALTER TABLE ONLY public.supporttickets DROP CONSTRAINT supporttickets_employeeid_fkey;
ALTER TABLE ONLY public.supporttickets DROP CONSTRAINT supporttickets_customerid_fkey;
ALTER TABLE ONLY public.products DROP CONSTRAINT products_supplierid_fkey;
ALTER TABLE ONLY public.products DROP CONSTRAINT products_categoryid_fkey;
ALTER TABLE ONLY public.orders DROP CONSTRAINT orders_customerid_fkey;
ALTER TABLE ONLY public.orders DROP CONSTRAINT orders_carrierid_fkey;
ALTER TABLE ONLY public.orderdetails DROP CONSTRAINT orderdetails_productid_fkey;
ALTER TABLE ONLY public.orderdetails DROP CONSTRAINT orderdetails_orderid_fkey;
ALTER TABLE ONLY public.employeehandles DROP CONSTRAINT employeehandles_ticketid_fkey;
ALTER TABLE ONLY public.employeehandles DROP CONSTRAINT employeehandles_employeeid_fkey;
ALTER TABLE ONLY public.accounts DROP CONSTRAINT accounts_email_fkey;
ALTER TABLE ONLY public.accounts DROP CONSTRAINT accounts_customerid_fkey;
ALTER TABLE ONLY public.supporttickets DROP CONSTRAINT supporttickets_pkey;
ALTER TABLE ONLY public.suppliers DROP CONSTRAINT suppliers_pkey;
ALTER TABLE ONLY public.products DROP CONSTRAINT products_pkey;
ALTER TABLE ONLY public.orders DROP CONSTRAINT orders_pkey;
ALTER TABLE ONLY public.orderdetails DROP CONSTRAINT orderdetails_pkey;
ALTER TABLE ONLY public.employees DROP CONSTRAINT employees_pkey;
ALTER TABLE ONLY public.employeehandles DROP CONSTRAINT employeehandles_pkey;
ALTER TABLE ONLY public.customers DROP CONSTRAINT customers_pkey;
ALTER TABLE ONLY public.customers DROP CONSTRAINT customers_email_key;
ALTER TABLE ONLY public.categories DROP CONSTRAINT categories_pkey;
ALTER TABLE ONLY public.carriers DROP CONSTRAINT carriers_pkey;
ALTER TABLE ONLY public.accounts DROP CONSTRAINT accounts_pkey;
ALTER TABLE ONLY public.accounts DROP CONSTRAINT accounts_email_key;
ALTER TABLE public.supporttickets ALTER COLUMN ticketid DROP DEFAULT;
ALTER TABLE public.suppliers ALTER COLUMN supplierid DROP DEFAULT;
ALTER TABLE public.products ALTER COLUMN productid DROP DEFAULT;
ALTER TABLE public.orders ALTER COLUMN orderid DROP DEFAULT;
ALTER TABLE public.orderdetails ALTER COLUMN detailid DROP DEFAULT;
ALTER TABLE public.employees ALTER COLUMN employeeid DROP DEFAULT;
ALTER TABLE public.customers ALTER COLUMN customerid DROP DEFAULT;
ALTER TABLE public.categories ALTER COLUMN categoryid DROP DEFAULT;
ALTER TABLE public.carriers ALTER COLUMN carrierid DROP DEFAULT;
ALTER TABLE public.accounts ALTER COLUMN userid DROP DEFAULT;
DROP SEQUENCE public.supporttickets_ticketid_seq;
DROP TABLE public.supporttickets;
DROP SEQUENCE public.suppliers_supplierid_seq;
DROP TABLE public.suppliers;
DROP SEQUENCE public.products_productid_seq;
DROP TABLE public.products;
DROP SEQUENCE public.orders_orderid_seq;
DROP TABLE public.orders;
DROP SEQUENCE public.orderdetails_detailid_seq;
DROP TABLE public.orderdetails;
DROP SEQUENCE public.employees_employeeid_seq;
DROP TABLE public.employees;
DROP TABLE public.employeehandles;
DROP SEQUENCE public.customers_customerid_seq;
DROP TABLE public.customers;
DROP SEQUENCE public.categories_categoryid_seq;
DROP TABLE public.categories;
DROP SEQUENCE public.carriers_carrierid_seq;
DROP TABLE public.carriers;
DROP SEQUENCE public.accounts_userid_seq;
DROP TABLE public.accounts;
DROP EXTENSION pg_stat_statements;
DROP EXTENSION pg_buffercache;
DROP EXTENSION plpgsql;
DROP SCHEMA public;
--
-- Name: public; Type: SCHEMA; Schema: -; Owner: azure_superuser
--

CREATE SCHEMA public;


ALTER SCHEMA public OWNER TO azure_superuser;

--
-- Name: SCHEMA public; Type: COMMENT; Schema: -; Owner: azure_superuser
--

COMMENT ON SCHEMA public IS 'standard public schema';


--
-- Name: plpgsql; Type: EXTENSION; Schema: -; Owner: 
--

CREATE EXTENSION IF NOT EXISTS plpgsql WITH SCHEMA pg_catalog;


--
-- Name: EXTENSION plpgsql; Type: COMMENT; Schema: -; Owner: 
--

COMMENT ON EXTENSION plpgsql IS 'PL/pgSQL procedural language';


--
-- Name: pg_buffercache; Type: EXTENSION; Schema: -; Owner: 
--

CREATE EXTENSION IF NOT EXISTS pg_buffercache WITH SCHEMA public;


--
-- Name: EXTENSION pg_buffercache; Type: COMMENT; Schema: -; Owner: 
--

COMMENT ON EXTENSION pg_buffercache IS 'examine the shared buffer cache';


--
-- Name: pg_stat_statements; Type: EXTENSION; Schema: -; Owner: 
--

CREATE EXTENSION IF NOT EXISTS pg_stat_statements WITH SCHEMA public;


--
-- Name: EXTENSION pg_stat_statements; Type: COMMENT; Schema: -; Owner: 
--

COMMENT ON EXTENSION pg_stat_statements IS 'track execution statistics of all SQL statements executed';


SET default_tablespace = '';

SET default_with_oids = false;

--
-- Name: accounts; Type: TABLE; Schema: public; Owner: myadmin
--

CREATE TABLE public.accounts (
    userid integer NOT NULL,
    email character varying(355) NOT NULL,
    password character varying(255) NOT NULL,
    customerid integer NOT NULL
);


ALTER TABLE public.accounts OWNER TO myadmin;

--
-- Name: accounts_userid_seq; Type: SEQUENCE; Schema: public; Owner: myadmin
--

CREATE SEQUENCE public.accounts_userid_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.accounts_userid_seq OWNER TO myadmin;

--
-- Name: accounts_userid_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: myadmin
--

ALTER SEQUENCE public.accounts_userid_seq OWNED BY public.accounts.userid;


--
-- Name: carriers; Type: TABLE; Schema: public; Owner: myadmin
--

CREATE TABLE public.carriers (
    carrierid integer NOT NULL,
    carriername character varying(255) NOT NULL
);


ALTER TABLE public.carriers OWNER TO myadmin;

--
-- Name: carriers_carrierid_seq; Type: SEQUENCE; Schema: public; Owner: myadmin
--

CREATE SEQUENCE public.carriers_carrierid_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.carriers_carrierid_seq OWNER TO myadmin;

--
-- Name: carriers_carrierid_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: myadmin
--

ALTER SEQUENCE public.carriers_carrierid_seq OWNED BY public.carriers.carrierid;


--
-- Name: categories; Type: TABLE; Schema: public; Owner: myadmin
--

CREATE TABLE public.categories (
    categoryid integer NOT NULL,
    categoryname character varying(255) NOT NULL
);


ALTER TABLE public.categories OWNER TO myadmin;

--
-- Name: categories_categoryid_seq; Type: SEQUENCE; Schema: public; Owner: myadmin
--

CREATE SEQUENCE public.categories_categoryid_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.categories_categoryid_seq OWNER TO myadmin;

--
-- Name: categories_categoryid_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: myadmin
--

ALTER SEQUENCE public.categories_categoryid_seq OWNED BY public.categories.categoryid;


--
-- Name: customers; Type: TABLE; Schema: public; Owner: myadmin
--

CREATE TABLE public.customers (
    customerid integer NOT NULL,
    fname character varying(255) NOT NULL,
    lname character varying(255) NOT NULL,
    phone character varying(20),
    email character varying(355) NOT NULL,
    address character varying(255) NOT NULL,
    city character varying(255) NOT NULL,
    state character varying(2) NOT NULL,
    zip character varying(10) NOT NULL
);


ALTER TABLE public.customers OWNER TO myadmin;

--
-- Name: customers_customerid_seq; Type: SEQUENCE; Schema: public; Owner: myadmin
--

CREATE SEQUENCE public.customers_customerid_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.customers_customerid_seq OWNER TO myadmin;

--
-- Name: customers_customerid_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: myadmin
--

ALTER SEQUENCE public.customers_customerid_seq OWNED BY public.customers.customerid;


--
-- Name: employeehandles; Type: TABLE; Schema: public; Owner: myadmin
--

CREATE TABLE public.employeehandles (
    ticketid integer NOT NULL,
    employeeid integer NOT NULL
);


ALTER TABLE public.employeehandles OWNER TO myadmin;

--
-- Name: employees; Type: TABLE; Schema: public; Owner: myadmin
--

CREATE TABLE public.employees (
    employeeid integer NOT NULL,
    fname character varying(255) NOT NULL,
    lname character varying(255) NOT NULL
);


ALTER TABLE public.employees OWNER TO myadmin;

--
-- Name: employees_employeeid_seq; Type: SEQUENCE; Schema: public; Owner: myadmin
--

CREATE SEQUENCE public.employees_employeeid_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.employees_employeeid_seq OWNER TO myadmin;

--
-- Name: employees_employeeid_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: myadmin
--

ALTER SEQUENCE public.employees_employeeid_seq OWNED BY public.employees.employeeid;


--
-- Name: orderdetails; Type: TABLE; Schema: public; Owner: myadmin
--

CREATE TABLE public.orderdetails (
    detailid integer NOT NULL,
    orderid integer NOT NULL,
    productid integer NOT NULL,
    quantity integer NOT NULL,
    totalprice integer NOT NULL
);


ALTER TABLE public.orderdetails OWNER TO myadmin;

--
-- Name: orderdetails_detailid_seq; Type: SEQUENCE; Schema: public; Owner: myadmin
--

CREATE SEQUENCE public.orderdetails_detailid_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.orderdetails_detailid_seq OWNER TO myadmin;

--
-- Name: orderdetails_detailid_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: myadmin
--

ALTER SEQUENCE public.orderdetails_detailid_seq OWNED BY public.orderdetails.detailid;


--
-- Name: orders; Type: TABLE; Schema: public; Owner: myadmin
--

CREATE TABLE public.orders (
    orderid integer NOT NULL,
    customerid integer NOT NULL,
    orderdate date NOT NULL,
    trackingno integer NOT NULL,
    carrierid integer NOT NULL
);


ALTER TABLE public.orders OWNER TO myadmin;

--
-- Name: orders_orderid_seq; Type: SEQUENCE; Schema: public; Owner: myadmin
--

CREATE SEQUENCE public.orders_orderid_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.orders_orderid_seq OWNER TO myadmin;

--
-- Name: orders_orderid_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: myadmin
--

ALTER SEQUENCE public.orders_orderid_seq OWNED BY public.orders.orderid;


--
-- Name: products; Type: TABLE; Schema: public; Owner: myadmin
--

CREATE TABLE public.products (
    productid integer NOT NULL,
    productname character varying(255) NOT NULL,
    price integer NOT NULL,
    inventory integer NOT NULL,
    categoryid integer NOT NULL,
    supplierid integer NOT NULL
);


ALTER TABLE public.products OWNER TO myadmin;

--
-- Name: products_productid_seq; Type: SEQUENCE; Schema: public; Owner: myadmin
--

CREATE SEQUENCE public.products_productid_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.products_productid_seq OWNER TO myadmin;

--
-- Name: products_productid_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: myadmin
--

ALTER SEQUENCE public.products_productid_seq OWNED BY public.products.productid;


--
-- Name: suppliers; Type: TABLE; Schema: public; Owner: myadmin
--

CREATE TABLE public.suppliers (
    supplierid integer NOT NULL,
    suppliername character varying(255)
);


ALTER TABLE public.suppliers OWNER TO myadmin;

--
-- Name: suppliers_supplierid_seq; Type: SEQUENCE; Schema: public; Owner: myadmin
--

CREATE SEQUENCE public.suppliers_supplierid_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.suppliers_supplierid_seq OWNER TO myadmin;

--
-- Name: suppliers_supplierid_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: myadmin
--

ALTER SEQUENCE public.suppliers_supplierid_seq OWNED BY public.suppliers.supplierid;


--
-- Name: supporttickets; Type: TABLE; Schema: public; Owner: myadmin
--

CREATE TABLE public.supporttickets (
    ticketid integer NOT NULL,
    customerid integer NOT NULL,
    supportmessage character varying(255),
    orderid integer,
    employeeid integer NOT NULL,
    ticketdate date NOT NULL
);


ALTER TABLE public.supporttickets OWNER TO myadmin;

--
-- Name: supporttickets_ticketid_seq; Type: SEQUENCE; Schema: public; Owner: myadmin
--

CREATE SEQUENCE public.supporttickets_ticketid_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.supporttickets_ticketid_seq OWNER TO myadmin;

--
-- Name: supporttickets_ticketid_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: myadmin
--

ALTER SEQUENCE public.supporttickets_ticketid_seq OWNED BY public.supporttickets.ticketid;


--
-- Name: accounts userid; Type: DEFAULT; Schema: public; Owner: myadmin
--

ALTER TABLE ONLY public.accounts ALTER COLUMN userid SET DEFAULT nextval('public.accounts_userid_seq'::regclass);


--
-- Name: carriers carrierid; Type: DEFAULT; Schema: public; Owner: myadmin
--

ALTER TABLE ONLY public.carriers ALTER COLUMN carrierid SET DEFAULT nextval('public.carriers_carrierid_seq'::regclass);


--
-- Name: categories categoryid; Type: DEFAULT; Schema: public; Owner: myadmin
--

ALTER TABLE ONLY public.categories ALTER COLUMN categoryid SET DEFAULT nextval('public.categories_categoryid_seq'::regclass);


--
-- Name: customers customerid; Type: DEFAULT; Schema: public; Owner: myadmin
--

ALTER TABLE ONLY public.customers ALTER COLUMN customerid SET DEFAULT nextval('public.customers_customerid_seq'::regclass);


--
-- Name: employees employeeid; Type: DEFAULT; Schema: public; Owner: myadmin
--

ALTER TABLE ONLY public.employees ALTER COLUMN employeeid SET DEFAULT nextval('public.employees_employeeid_seq'::regclass);


--
-- Name: orderdetails detailid; Type: DEFAULT; Schema: public; Owner: myadmin
--

ALTER TABLE ONLY public.orderdetails ALTER COLUMN detailid SET DEFAULT nextval('public.orderdetails_detailid_seq'::regclass);


--
-- Name: orders orderid; Type: DEFAULT; Schema: public; Owner: myadmin
--

ALTER TABLE ONLY public.orders ALTER COLUMN orderid SET DEFAULT nextval('public.orders_orderid_seq'::regclass);


--
-- Name: products productid; Type: DEFAULT; Schema: public; Owner: myadmin
--

ALTER TABLE ONLY public.products ALTER COLUMN productid SET DEFAULT nextval('public.products_productid_seq'::regclass);


--
-- Name: suppliers supplierid; Type: DEFAULT; Schema: public; Owner: myadmin
--

ALTER TABLE ONLY public.suppliers ALTER COLUMN supplierid SET DEFAULT nextval('public.suppliers_supplierid_seq'::regclass);


--
-- Name: supporttickets ticketid; Type: DEFAULT; Schema: public; Owner: myadmin
--

ALTER TABLE ONLY public.supporttickets ALTER COLUMN ticketid SET DEFAULT nextval('public.supporttickets_ticketid_seq'::regclass);


--
-- Data for Name: accounts; Type: TABLE DATA; Schema: public; Owner: myadmin
--

COPY public.accounts (userid, email, password, customerid) FROM stdin;
\.
COPY public.accounts (userid, email, password, customerid) FROM '$$PATH$$/3589.dat';

--
-- Data for Name: carriers; Type: TABLE DATA; Schema: public; Owner: myadmin
--

COPY public.carriers (carrierid, carriername) FROM stdin;
\.
COPY public.carriers (carrierid, carriername) FROM '$$PATH$$/3583.dat';

--
-- Data for Name: categories; Type: TABLE DATA; Schema: public; Owner: myadmin
--

COPY public.categories (categoryid, categoryname) FROM stdin;
\.
COPY public.categories (categoryid, categoryname) FROM '$$PATH$$/3581.dat';

--
-- Data for Name: customers; Type: TABLE DATA; Schema: public; Owner: myadmin
--

COPY public.customers (customerid, fname, lname, phone, email, address, city, state, zip) FROM stdin;
\.
COPY public.customers (customerid, fname, lname, phone, email, address, city, state, zip) FROM '$$PATH$$/3587.dat';

--
-- Data for Name: employeehandles; Type: TABLE DATA; Schema: public; Owner: myadmin
--

COPY public.employeehandles (ticketid, employeeid) FROM stdin;
\.
COPY public.employeehandles (ticketid, employeeid) FROM '$$PATH$$/3600.dat';

--
-- Data for Name: employees; Type: TABLE DATA; Schema: public; Owner: myadmin
--

COPY public.employees (employeeid, fname, lname) FROM stdin;
\.
COPY public.employees (employeeid, fname, lname) FROM '$$PATH$$/3585.dat';

--
-- Data for Name: orderdetails; Type: TABLE DATA; Schema: public; Owner: myadmin
--

COPY public.orderdetails (detailid, orderid, productid, quantity, totalprice) FROM stdin;
\.
COPY public.orderdetails (detailid, orderid, productid, quantity, totalprice) FROM '$$PATH$$/3599.dat';

--
-- Data for Name: orders; Type: TABLE DATA; Schema: public; Owner: myadmin
--

COPY public.orders (orderid, customerid, orderdate, trackingno, carrierid) FROM stdin;
\.
COPY public.orders (orderid, customerid, orderdate, trackingno, carrierid) FROM '$$PATH$$/3591.dat';

--
-- Data for Name: products; Type: TABLE DATA; Schema: public; Owner: myadmin
--

COPY public.products (productid, productname, price, inventory, categoryid, supplierid) FROM stdin;
\.
COPY public.products (productid, productname, price, inventory, categoryid, supplierid) FROM '$$PATH$$/3595.dat';

--
-- Data for Name: suppliers; Type: TABLE DATA; Schema: public; Owner: myadmin
--

COPY public.suppliers (supplierid, suppliername) FROM stdin;
\.
COPY public.suppliers (supplierid, suppliername) FROM '$$PATH$$/3593.dat';

--
-- Data for Name: supporttickets; Type: TABLE DATA; Schema: public; Owner: myadmin
--

COPY public.supporttickets (ticketid, customerid, supportmessage, orderid, employeeid, ticketdate) FROM stdin;
\.
COPY public.supporttickets (ticketid, customerid, supportmessage, orderid, employeeid, ticketdate) FROM '$$PATH$$/3597.dat';

--
-- Name: accounts_userid_seq; Type: SEQUENCE SET; Schema: public; Owner: myadmin
--

SELECT pg_catalog.setval('public.accounts_userid_seq', 100, true);


--
-- Name: carriers_carrierid_seq; Type: SEQUENCE SET; Schema: public; Owner: myadmin
--

SELECT pg_catalog.setval('public.carriers_carrierid_seq', 1, true);


--
-- Name: categories_categoryid_seq; Type: SEQUENCE SET; Schema: public; Owner: myadmin
--

SELECT pg_catalog.setval('public.categories_categoryid_seq', 7, true);


--
-- Name: customers_customerid_seq; Type: SEQUENCE SET; Schema: public; Owner: myadmin
--

SELECT pg_catalog.setval('public.customers_customerid_seq', 1, false);


--
-- Name: employees_employeeid_seq; Type: SEQUENCE SET; Schema: public; Owner: myadmin
--

SELECT pg_catalog.setval('public.employees_employeeid_seq', 1, false);


--
-- Name: orderdetails_detailid_seq; Type: SEQUENCE SET; Schema: public; Owner: myadmin
--

SELECT pg_catalog.setval('public.orderdetails_detailid_seq', 250, true);


--
-- Name: orders_orderid_seq; Type: SEQUENCE SET; Schema: public; Owner: myadmin
--

SELECT pg_catalog.setval('public.orders_orderid_seq', 1, false);


--
-- Name: products_productid_seq; Type: SEQUENCE SET; Schema: public; Owner: myadmin
--

SELECT pg_catalog.setval('public.products_productid_seq', 54, true);


--
-- Name: suppliers_supplierid_seq; Type: SEQUENCE SET; Schema: public; Owner: myadmin
--

SELECT pg_catalog.setval('public.suppliers_supplierid_seq', 100, true);


--
-- Name: supporttickets_ticketid_seq; Type: SEQUENCE SET; Schema: public; Owner: myadmin
--

SELECT pg_catalog.setval('public.supporttickets_ticketid_seq', 1, false);


--
-- Name: accounts accounts_email_key; Type: CONSTRAINT; Schema: public; Owner: myadmin
--

ALTER TABLE ONLY public.accounts
    ADD CONSTRAINT accounts_email_key UNIQUE (email);


--
-- Name: accounts accounts_pkey; Type: CONSTRAINT; Schema: public; Owner: myadmin
--

ALTER TABLE ONLY public.accounts
    ADD CONSTRAINT accounts_pkey PRIMARY KEY (userid);


--
-- Name: carriers carriers_pkey; Type: CONSTRAINT; Schema: public; Owner: myadmin
--

ALTER TABLE ONLY public.carriers
    ADD CONSTRAINT carriers_pkey PRIMARY KEY (carrierid);


--
-- Name: categories categories_pkey; Type: CONSTRAINT; Schema: public; Owner: myadmin
--

ALTER TABLE ONLY public.categories
    ADD CONSTRAINT categories_pkey PRIMARY KEY (categoryid);


--
-- Name: customers customers_email_key; Type: CONSTRAINT; Schema: public; Owner: myadmin
--

ALTER TABLE ONLY public.customers
    ADD CONSTRAINT customers_email_key UNIQUE (email);


--
-- Name: customers customers_pkey; Type: CONSTRAINT; Schema: public; Owner: myadmin
--

ALTER TABLE ONLY public.customers
    ADD CONSTRAINT customers_pkey PRIMARY KEY (customerid);


--
-- Name: employeehandles employeehandles_pkey; Type: CONSTRAINT; Schema: public; Owner: myadmin
--

ALTER TABLE ONLY public.employeehandles
    ADD CONSTRAINT employeehandles_pkey PRIMARY KEY (ticketid, employeeid);


--
-- Name: employees employees_pkey; Type: CONSTRAINT; Schema: public; Owner: myadmin
--

ALTER TABLE ONLY public.employees
    ADD CONSTRAINT employees_pkey PRIMARY KEY (employeeid);


--
-- Name: orderdetails orderdetails_pkey; Type: CONSTRAINT; Schema: public; Owner: myadmin
--

ALTER TABLE ONLY public.orderdetails
    ADD CONSTRAINT orderdetails_pkey PRIMARY KEY (detailid);


--
-- Name: orders orders_pkey; Type: CONSTRAINT; Schema: public; Owner: myadmin
--

ALTER TABLE ONLY public.orders
    ADD CONSTRAINT orders_pkey PRIMARY KEY (orderid);


--
-- Name: products products_pkey; Type: CONSTRAINT; Schema: public; Owner: myadmin
--

ALTER TABLE ONLY public.products
    ADD CONSTRAINT products_pkey PRIMARY KEY (productid);


--
-- Name: suppliers suppliers_pkey; Type: CONSTRAINT; Schema: public; Owner: myadmin
--

ALTER TABLE ONLY public.suppliers
    ADD CONSTRAINT suppliers_pkey PRIMARY KEY (supplierid);


--
-- Name: supporttickets supporttickets_pkey; Type: CONSTRAINT; Schema: public; Owner: myadmin
--

ALTER TABLE ONLY public.supporttickets
    ADD CONSTRAINT supporttickets_pkey PRIMARY KEY (ticketid);


--
-- Name: accounts accounts_customerid_fkey; Type: FK CONSTRAINT; Schema: public; Owner: myadmin
--

ALTER TABLE ONLY public.accounts
    ADD CONSTRAINT accounts_customerid_fkey FOREIGN KEY (customerid) REFERENCES public.customers(customerid);


--
-- Name: accounts accounts_email_fkey; Type: FK CONSTRAINT; Schema: public; Owner: myadmin
--

ALTER TABLE ONLY public.accounts
    ADD CONSTRAINT accounts_email_fkey FOREIGN KEY (email) REFERENCES public.customers(email);


--
-- Name: employeehandles employeehandles_employeeid_fkey; Type: FK CONSTRAINT; Schema: public; Owner: myadmin
--

ALTER TABLE ONLY public.employeehandles
    ADD CONSTRAINT employeehandles_employeeid_fkey FOREIGN KEY (employeeid) REFERENCES public.employees(employeeid) ON DELETE CASCADE;


--
-- Name: employeehandles employeehandles_ticketid_fkey; Type: FK CONSTRAINT; Schema: public; Owner: myadmin
--

ALTER TABLE ONLY public.employeehandles
    ADD CONSTRAINT employeehandles_ticketid_fkey FOREIGN KEY (ticketid) REFERENCES public.supporttickets(ticketid) ON DELETE CASCADE;


--
-- Name: orderdetails orderdetails_orderid_fkey; Type: FK CONSTRAINT; Schema: public; Owner: myadmin
--

ALTER TABLE ONLY public.orderdetails
    ADD CONSTRAINT orderdetails_orderid_fkey FOREIGN KEY (orderid) REFERENCES public.orders(orderid);


--
-- Name: orderdetails orderdetails_productid_fkey; Type: FK CONSTRAINT; Schema: public; Owner: myadmin
--

ALTER TABLE ONLY public.orderdetails
    ADD CONSTRAINT orderdetails_productid_fkey FOREIGN KEY (productid) REFERENCES public.products(productid);


--
-- Name: orders orders_carrierid_fkey; Type: FK CONSTRAINT; Schema: public; Owner: myadmin
--

ALTER TABLE ONLY public.orders
    ADD CONSTRAINT orders_carrierid_fkey FOREIGN KEY (carrierid) REFERENCES public.carriers(carrierid);


--
-- Name: orders orders_customerid_fkey; Type: FK CONSTRAINT; Schema: public; Owner: myadmin
--

ALTER TABLE ONLY public.orders
    ADD CONSTRAINT orders_customerid_fkey FOREIGN KEY (customerid) REFERENCES public.customers(customerid);


--
-- Name: products products_categoryid_fkey; Type: FK CONSTRAINT; Schema: public; Owner: myadmin
--

ALTER TABLE ONLY public.products
    ADD CONSTRAINT products_categoryid_fkey FOREIGN KEY (categoryid) REFERENCES public.categories(categoryid);


--
-- Name: products products_supplierid_fkey; Type: FK CONSTRAINT; Schema: public; Owner: myadmin
--

ALTER TABLE ONLY public.products
    ADD CONSTRAINT products_supplierid_fkey FOREIGN KEY (supplierid) REFERENCES public.suppliers(supplierid);


--
-- Name: supporttickets supporttickets_customerid_fkey; Type: FK CONSTRAINT; Schema: public; Owner: myadmin
--

ALTER TABLE ONLY public.supporttickets
    ADD CONSTRAINT supporttickets_customerid_fkey FOREIGN KEY (customerid) REFERENCES public.customers(customerid);


--
-- Name: supporttickets supporttickets_employeeid_fkey; Type: FK CONSTRAINT; Schema: public; Owner: myadmin
--

ALTER TABLE ONLY public.supporttickets
    ADD CONSTRAINT supporttickets_employeeid_fkey FOREIGN KEY (employeeid) REFERENCES public.employees(employeeid);


--
-- Name: supporttickets supporttickets_orderid_fkey; Type: FK CONSTRAINT; Schema: public; Owner: myadmin
--

ALTER TABLE ONLY public.supporttickets
    ADD CONSTRAINT supporttickets_orderid_fkey FOREIGN KEY (orderid) REFERENCES public.orders(orderid);


--
-- PostgreSQL database dump complete
--

